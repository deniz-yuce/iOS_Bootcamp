//
//  CartVC.swift
//  AkisYemek
//
//  Created by Deniz Yüce on 28.05.2022.
//

import UIKit

class CartVC: UIViewController {

    @IBOutlet weak var cartTableView: UITableView!
    
    var foodsInCartList = [FoodsInCart]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        cartTableView.delegate = self
        cartTableView.dataSource = self

        let f1 = FoodsInCart(sepet_yemek_id: 1, yemek_adi: "elma", yemek_resim_adi: "bilgisayar", yemek_fiyat: "3", yemek_siparis_adet: 5, kullanici_adi: "Deniz")
        let f2 = FoodsInCart(sepet_yemek_id: 2, yemek_adi: "muz", yemek_resim_adi: "gozluk", yemek_fiyat: "15", yemek_siparis_adet: 6, kullanici_adi: "Deniz")
        let f3 = FoodsInCart(sepet_yemek_id: 3, yemek_adi: "kofte", yemek_resim_adi: "kulaklik", yemek_fiyat: "30", yemek_siparis_adet: 3, kullanici_adi: "Deniz")
        let f4 = FoodsInCart(sepet_yemek_id: 4, yemek_adi: "ayran", yemek_resim_adi: "parfum", yemek_fiyat: "8", yemek_siparis_adet: 7, kullanici_adi: "Deniz")
        let f5 = FoodsInCart(sepet_yemek_id: 5, yemek_adi: "tatlı", yemek_resim_adi: "saat", yemek_fiyat: "20", yemek_siparis_adet: 8, kullanici_adi: "Deniz")
        let f6 = FoodsInCart(sepet_yemek_id: 6, yemek_adi: "kola", yemek_resim_adi: "supurge", yemek_fiyat: "10", yemek_siparis_adet: 2, kullanici_adi: "Deniz")
        let f7 = FoodsInCart(sepet_yemek_id: 7, yemek_adi: "yoğurt", yemek_resim_adi: "telefon", yemek_fiyat: "5", yemek_siparis_adet: 1, kullanici_adi: "Deniz")
        foodsInCartList.append(f1)
        foodsInCartList.append(f2)
        foodsInCartList.append(f3)
        foodsInCartList.append(f4)
        foodsInCartList.append(f5)
        foodsInCartList.append(f6)
        foodsInCartList.append(f7)
    }
    
}

//sildikten sonra update yapılamlı


extension CartVC :UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return foodsInCartList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let foodInCart = foodsInCartList[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cartCell", for: indexPath) as! CartTableViewCell
        
        cell.cartImageView.image = UIImage(named: foodInCart.yemek_resim_adi!)
        cell.cartNameLabel.text = foodInCart.yemek_adi
        cell.cartAmountLabel.text = "\(foodInCart.yemek_siparis_adet!) x"
        cell.cartPriceLabel.text = "\(Int(foodInCart.yemek_fiyat!)!*foodInCart.yemek_siparis_adet!)₺"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete"){ (action,view,void) in
            let foodInCart = self.foodsInCartList[indexPath.row]
            
            let alert = UIAlertController(title: "Remove", message: "Remove \(foodInCart.yemek_adi!)", preferredStyle: .alert)
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) {action in}
            alert.addAction(cancelAction)
            
            let yesAction = UIAlertAction(title: "Yes", style: .destructive) {action in
                print("\(foodInCart.yemek_adi!) with \(foodInCart.sepet_yemek_id!) id is deleted.")
            }
            alert.addAction(yesAction)
            self.present(alert, animated: true)
            
            //do deleting here with index path
        }
        
        return UISwipeActionsConfiguration(actions: [deleteAction])
    }
    
    
}
