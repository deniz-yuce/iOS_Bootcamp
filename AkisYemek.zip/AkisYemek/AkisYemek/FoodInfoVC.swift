//
//  FoodInfoVC.swift
//  AkisYemek
//
//  Created by Deniz Yüce on 28.05.2022.
//

import UIKit

class FoodInfoVC: UIViewController {

    @IBOutlet weak var foodInfoImage: UIImageView! //kullanılcak mı?
    @IBOutlet weak var foodInfoNameLabel: UILabel!
    @IBOutlet weak var foodInfoPriceLabel: UILabel!
    @IBOutlet weak var foodInfoAmountLabel: UILabel!
    @IBOutlet weak var stepper: UIStepper!
    
    var food:Foods?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let f = food {
            foodInfoImage.image = UIImage(named: f.yemek_resim_adi!)
            foodInfoNameLabel.text = f.yemek_adi
            foodInfoPriceLabel.text = "\(f.yemek_fiyat!)₺"
        }
    }
    
    
    @IBAction func amountChange(_ sender: UIStepper) {
        foodInfoAmountLabel.text = String(Int(sender.value))
        print("Amount : \(Int(stepper.value))")
    }
    
    @IBAction func addToCart(_ sender: Any) {
        if let foodName = food?.yemek_adi, let foodPrice = food?.yemek_fiyat
            , let foodAmount = Int(foodInfoAmountLabel.text!) {
            add(yemek_adi: foodName, yemek_fiyat: foodPrice, yemek_siparis_adet: foodAmount)
        }
    }
    
    func add(yemek_adi:String,yemek_fiyat:Int,yemek_siparis_adet:Int) { //sepet_yemek_id?
        print("Adding to cart : \(yemek_adi) - \(yemek_fiyat) - \(yemek_siparis_adet)")
        //(yemek_resim_adi) göndercen
        //var ex = "Deniz"
        //print(ex.lowercased()) OLARAK GONDER + USER ID GÖNDERCEN
        //FoodsInCart() nesnesi olarak gönder
    }
    
}
