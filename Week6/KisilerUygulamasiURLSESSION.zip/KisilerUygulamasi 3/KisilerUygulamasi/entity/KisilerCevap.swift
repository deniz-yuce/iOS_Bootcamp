//
//  KisilerCevap.swift
//  KisilerUygulamasi
//
//  Created by Deniz Yüce on 7.05.2022.
//

import Foundation

class KisilerCevap : Codable {
    var kisiler:[Kisiler]?
    var success:Int?
}
