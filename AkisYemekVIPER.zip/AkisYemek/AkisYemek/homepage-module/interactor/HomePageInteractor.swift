//
//  HomePageInteractor.swift
//  AkisYemek
//
//  Created by Deniz Yüce on 28.05.2022.
//

import Foundation

class HomePageInteractor : PresenterToInteractorHomePageProtocol {
    var homePagePresenter: InteractorToPresenterHomePageProtocol?
    
    func getAllFoods() {
        var list = [Foods]()
        let f1 = Foods(yemek_id: 1, yemek_adi: "elma", yemek_resim_adi: "bilgisayar", yemek_fiyat: 3)
        let f2 = Foods(yemek_id: 2, yemek_adi: "muz", yemek_resim_adi: "gozluk", yemek_fiyat: 15)
        let f3 = Foods(yemek_id: 3, yemek_adi: "kofte", yemek_resim_adi: "kulaklik", yemek_fiyat: 30)
        let f4 = Foods(yemek_id: 4, yemek_adi: "ayran", yemek_resim_adi: "parfum", yemek_fiyat: 8)
        let f5 = Foods(yemek_id: 5, yemek_adi: "tatlı", yemek_resim_adi: "saat", yemek_fiyat: 20)
        let f6 = Foods(yemek_id: 6, yemek_adi: "kola", yemek_resim_adi: "supurge", yemek_fiyat: 10)
        let f7 = Foods(yemek_id: 7, yemek_adi: "yoğurt", yemek_resim_adi: "telefon", yemek_fiyat: 5)
        list.append(f1)
        list.append(f2)
        list.append(f3)
        list.append(f4)
        list.append(f5)
        list.append(f6)
        list.append(f7)
        homePagePresenter?.sendDataToPresenter(foodsList: list)
    }
}
